<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Edit l'abonnement
        </div>
        <div class="card-body">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <div class="card card-primary">
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
                            <?php endif; ?>

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form  action="<?php echo e(url('pack/'.$pack->id)); ?>" method="post">
                            <input type="hidden" name="_method" value="PUT">
                            <?php echo e(csrf_field()); ?>

                            <div class="card-body">
                            <div class="form-group">
                                    <label class="h6">Client</label><?php echo e($pack->client_id); ?>

                                    <select name="client" id="" class="form-control">
                                        <option value="">-- choisir un client --</option>
                                        <?php $__currentLoopData = $listclient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>" <?php echo e($client->id == $pack->client_id ? 'selected' : ''); ?>><?php echo e($client->nom.' '.$client->prenom); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                                </div>
                                <div class="row">
                                    <div class="form-group col">
                                        <label class="h6">Date de creation</label>
                                        <input type="date"  name="date_creation" value="<?php echo e($pack->date_creation); ?>" class="form-control" >
                                        <span class="text-danger"><?php echo e($errors->first('date_creation')); ?></span>
                                    </div>
                                    <div class="form-group col">
                                        <label class="h6">Date d'experation</label>
                                        <input type="date"  name="date_experation" value="<?php echo e($pack->date_experation); ?>" class="form-control" >
                                        <span class="text-danger"><?php echo e($errors->first('date_experation')); ?></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Status </label>
                                    <select name="status" class="form-control"  >
                                        <option value="">-- Choisir --</option>
                                        <option value="active" <?php echo e(($pack->status ==='active') ? 'selected' : ''); ?>>Active</option>
                                        <option value="expire"<?php echo e(($pack->status ==='expire') ? 'selected' : ''); ?>>Expiré</option>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Forniceur</label>
                                    <input type="text"  name="forniceur" value="<?php echo e($pack->forniceur); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('forniceur')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Serveur</label>
                                    <input type="text"  name="serveur" value="<?php echo e($pack->serveur); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('serveur')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Panel</label>
                                    <input type="text"  name="panel" value="<?php echo e($pack->panel); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('panel')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Username</label>
                                    <input type="text"  name="username" value="<?php echo e($pack->username); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Prix</label>
                                    <input type="text"  name="prix" value="<?php echo e($pack->prix); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('prix')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Avence</label>
                                    <input type="text"  name="avence" value="<?php echo e($pack->avence); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('avence')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Moyen paiment</label>
                                    <input type="text"  name="moyen_paiment" value="<?php echo e($pack->moyen_paiment); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('moyen_paiment')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Status paiment</label>
                                    <select  name="status_paiment" class="form-control" >
                                        <option value="">-- Choisir --</option>
                                        <option value="non payé" <?php echo e(($pack->status_paiment ==='non payé') ? 'selected' : ''); ?> >Non payé</option>
                                        <option value="avence" <?php echo e(($pack->status_paiment ==='avence') ? 'selected' : ''); ?> >Avence</option>
                                        <option value="payé" <?php echo e(($pack->status_paiment ==='payé') ? 'selected' : ''); ?> >payé</option>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('status_paiment')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">M3u</label>
                                    <input type="text"  name="m3u" value="<?php echo e($pack->m3u); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('m3u')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label class="h6">Remarque</label>
                                    <textarea class="form-control"  name="remarque" value="<?php echo e($pack->remarque); ?>" rows="3"></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('remarque')); ?></span>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Edit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iptv\resources\views/layouts/pack/edit.blade.php ENDPATH**/ ?>