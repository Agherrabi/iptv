<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            List des Client
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Nom complet</th>
                        <th>Abennement</th>
                        <th>Paye</th>
                        <th>Ville</th>
                        <th>Tel</th>
                        <th>Adpress Mac/App</th>
                        <th style='width:60px'>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $listclient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($client->nom.' '.$client->prenom); ?></td>
                        <td><?php echo e($client->abonnement); ?></td>
                        <td><?php echo e($client->paye); ?></td>
                        <td><?php echo e($client->ville); ?></td>
                        <td><?php echo e($client->tel); ?></td>
                        <td><?php echo e($client->adress_mac); ?></td>
                        <td>
                            <form action="<?php echo e(route('client.destroy',$client->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <a href="<?php echo e(url('client/'.$client->id.'/edit')); ?>" class="btn btn-sm btn-success"><i class="fas fa-edit"></i></a>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>

                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iptv\resources\views/layouts/client/index.blade.php ENDPATH**/ ?>