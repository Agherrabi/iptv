<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Ajouter un client
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <div class="card card-primary">
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
                            <?php endif; ?>

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form  action="<?php echo e(url('client')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="card-body">

                            <div class="form-group">
                                <label >Nom de client </label>
                                <input type="text"  name="nom" class="form-control" placeholder="nom" value="<?php echo e(old('nom')); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('nom')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >Prenom</label>
                                <input type="text"  name="prenom" class="form-control" placeholder="Prenom" value="<?php echo e(old('prenom')); ?>">
                                <span class="text-danger"><?php echo e($errors->first('prenom')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >N Abonnement </label>
                                <input type="text"  name="abonnement" class="form-control" placeholder="Abonnement" value="<?php echo e(old('Abonnement')); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('abonnement')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >Paye</label>
                                <input type="text"  name="paye" class="form-control" placeholder="Paye" value="<?php echo e(old('paye')); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('paye')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >Ville</label>
                                <input type="text"  name="ville" class="form-control" placeholder="Ville" value="<?php echo e(old('ville')); ?>">
                                <span class="text-danger"><?php echo e($errors->first('ville')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >Tel</label>
                                <input type="text"  name="tel" class="form-control" placeholder="Tel" value="<?php echo e(old('tel')); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('tel')); ?></span>
                            </div>
                            <div class="form-group">
                                <label >Adress mac/App</label>
                                <input type="text"  name="adress_mac" class="form-control" placeholder="Adress mac" value="<?php echo e(old('adress_mac')); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('adress_mac')); ?></span>
                            </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Ajouter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iptv\resources\views/layouts/client/create.blade.php ENDPATH**/ ?>