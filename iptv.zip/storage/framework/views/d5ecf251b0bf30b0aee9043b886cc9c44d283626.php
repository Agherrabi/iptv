<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Ajouter un Abonnement
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <div class="card card-primary">
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
                            <?php endif; ?>

                        <!-- /.card-header -->
                        <!-- form start -->
                        <form  action="<?php echo e(url('pack')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="card-body">
                                <div class="form-group">
                                    <label >Client</label>
                                    <select name="client" id="" class="form-control">
                                        <option value="">-- choisir un client --</option>
                                        <?php $__currentLoopData = $listclient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom.' '.$client->prenom); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Date de creation</label>
                                    <input type="date"  name="date_creation" value="<?php echo e(old('date_creation')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('date_creation')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Date d'experation</label>
                                    <input type="date"  name="date_experation" value="<?php echo e(old('date_experation')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('date_experation')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Status </label>
                                    <select name="status" class="form-control" >
                                        <option value="">-- Choisir --</option>
                                        <option value="active">Active</option>
                                        <option value="expire">Expiré</option>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Forniceur</label>
                                    <input type="text"  name="forniceur" value="<?php echo e(old('forniceur')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('forniceur')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Serveur</label>
                                    <input type="text"  name="serveur" value="<?php echo e(old('serveur')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('serveur')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Panel</label>
                                    <input type="text"  name="panel" value="<?php echo e(old('panel')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('panel')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Username</label>
                                    <input type="text"  name="username" value="<?php echo e(old('username')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Prix</label>
                                    <input type="text"  name="prix" value="<?php echo e(old('prix')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('prix')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Avence</label>
                                    <input type="text"  name="avence" value="<?php echo e(old('avence')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('avence')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Moyen paiment</label>
                                    <input type="text"  name="moyen_paiment" value="<?php echo e(old('moyen_paiment')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('moyen_paiment')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Status paiment</label>
                                    <select  name="status_paiment" class="form-control" style="" required>
                                        <option value="">-- Choisir --</option>
                                        <option value="non payé" >Non payé</option>
                                        <option value="avence" >Avence</option>
                                        <option value="payé" >payé</option>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('status_paiment')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >M3u</label>
                                    <input type="text"  name="m3u" value="<?php echo e(old('m3u')); ?>" class="form-control" >
                                    <span class="text-danger"><?php echo e($errors->first('m3u')); ?></span>
                                </div>
                                <div class="form-group">
                                    <label >Remarque</label>
                                    <textarea class="form-control"  name="remarque" value="<?php echo e(old('remarque')); ?>" rows="3"></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('remarque')); ?></span>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Ajouter</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iptv\resources\views/layouts/pack/create.blade.php ENDPATH**/ ?>